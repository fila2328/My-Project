
import java.io.*;
import java.net.Socket;
import java.net.URL;
import javax.swing.*;
import java.awt.*;

public class ChatClient {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private JFrame frame;
    private JPanel chatPanel;
    private JTextField inputField;
    private String clientName;

    public ChatClient(String serverAddress, int port) {
        initializeUI();
        connectToServer(serverAddress, port);
    }
    
    private void initializeUI() {
        frame = new JFrame("Chat Client");
        
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        statusPanel.setBackground(new Color(240, 255, 240, 200));
        
        JLabel statusDot = new JLabel("●");
        statusDot.setFont(new Font("SansSerif", Font.BOLD, 12));
        statusDot.setForeground(Color.RED);
        statusDot.setToolTipText("Offline");
        
        JLabel statusLabel = new JLabel("Offline");
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        
        statusPanel.add(statusDot);
        statusPanel.add(statusLabel);
        
        chatPanel = new BackgroundPanel("https://images.unsplash.com/photo-1634733988136-ba4c7f5e6a8a");
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        
        JScrollPane scrollPane = new JScrollPane(chatPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(null);
        
        inputField = new JTextField(30);
        
        JButton sendButton = new JButton("➤");
        sendButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        sendButton.setForeground(new Color(0, 0, 205));
        sendButton.setBackground(new Color(173, 216, 230, 200));
        sendButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        sendButton.setFocusPainted(false);
        sendButton.setOpaque(true);
        
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBackground(new Color(240, 255, 240, 200));
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        
        BackgroundPanel mainBackground = new BackgroundPanel("https://plus.unsplash.com/premium_photo-1677252438450-b779a923b0f6?q=80&w=880&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D");
        mainBackground.setLayout(new BorderLayout());
        frame.setContentPane(mainBackground);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setOpaque(false);
        mainPanel.add(statusPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(inputPanel, BorderLayout.SOUTH);
        
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());
        
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        statusDot.setName("StatusDot");
        statusLabel.setName("StatusLabel");
    }

    private void connectToServer(String serverAddress, int port) {
        new Thread(() -> {
            try {
                socket = new Socket(serverAddress, port);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);


clientName = JOptionPane.showInputDialog(frame, "Enter your name:", "Name", JOptionPane.PLAIN_MESSAGE);
                if (clientName == null || clientName.trim().isEmpty()) {
                    clientName = "User" + (int)(Math.random() * 1000);
                }
                out.println(clientName);
                
                SwingUtilities.invokeLater(() -> {
                    frame.setTitle("Chat - " + clientName);
                    updateStatus(true);
                });

                startMessageListener();
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> 
                    JOptionPane.showMessageDialog(frame, "Connection failed: " + e.getMessage())
                );
            }
        }).start();
    }

    private void updateStatus(boolean isOnline) {
        findAndUpdateStatusComponents((JPanel)frame.getContentPane(), isOnline);
    }

    private void findAndUpdateStatusComponents(Container container, boolean isOnline) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JLabel) {
                JLabel label = (JLabel) comp;
                if ("●".equals(label.getText())) {
                    label.setForeground(isOnline ? Color.GREEN : Color.RED);
                } else if ("Offline".equals(label.getText()) || "Online".equals(label.getText())) {
                    label.setText(isOnline ? "Online" : "Offline");
                }
            } else if (comp instanceof Container) {
                findAndUpdateStatusComponents((Container) comp, isOnline);
            }
        }
    }

    private void startMessageListener() {
        new Thread(() -> {
            try {
                String message;
                while ((message = in.readLine()) != null) {
                    final String receivedMessage = message;
                    SwingUtilities.invokeLater(() -> {
                        // ✨ FIX: Replace clientName with "You" for your own messages
                        if (receivedMessage.startsWith(clientName + ":")) {
                            // This is YOUR message - show "You:" instead of your name
                            String youMessage = "You:" + receivedMessage.substring(clientName.length() + 1);
                            addMessage(youMessage, true); // true = isUser (right side)
                        } else {
                            // This is someone else's message
                            addMessage(receivedMessage, false); // false = not user (left side)
                        }
                    });
                }
            } catch (IOException e) {
                SwingUtilities.invokeLater(() -> {
                    addSystemMessage("Disconnected from server");
                    updateStatus(false);
                });
            }
        }).start();
    }

    private void sendMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty() && out != null) {
            out.println(message); // Send to server
            inputField.setText("");
        }
    }

    private void addMessage(String text, boolean isUser) {
        MessageBubble bubble = new MessageBubble(text, isUser);
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setMaximumSize(new Dimension(Integer.MAX_VALUE, bubble.getPreferredSize().height));
        wrapper.add(bubble, isUser ? BorderLayout.EAST : BorderLayout.WEST);
        wrapper.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        chatPanel.add(wrapper);
        chatPanel.revalidate();
        chatPanel.repaint();
        
        // Auto-scroll to bottom
        SwingUtilities.invokeLater(() -> {
            Component parent = chatPanel.getParent();
            if (parent instanceof JViewport) {
                JScrollPane scrollPane = (JScrollPane) parent.getParent();
                JScrollBar vertical = scrollPane.getVerticalScrollBar();
                vertical.setValue(vertical.getMaximum());
            }
        });
    }


private void addSystemMessage(String text) {
        JLabel systemLabel = new JLabel(text, SwingConstants.CENTER);
        systemLabel.setForeground(Color.GRAY);
        systemLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(systemLabel, BorderLayout.CENTER);
        wrapper.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        chatPanel.add(wrapper);
        chatPanel.revalidate();
        chatPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String serverAddress = JOptionPane.showInputDialog("Enter server IP:", "localhost");
            if (serverAddress == null) serverAddress = "localhost";
            new ChatClient(serverAddress, 5000);
        });
    }
}

// Background Image Panel
class BackgroundPanel extends JPanel {
    private Image backgroundImage;

    public BackgroundPanel(String imageUrl) {
        try {
            backgroundImage = new ImageIcon(new URL(imageUrl)).getImage();
        } catch (Exception e) {
            backgroundImage = null;
            setBackground(new Color(240, 255, 240));
        }
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}

// Message Bubble Component
class MessageBubble extends JPanel {
    private String text;
    private boolean isUser;
    private String timestamp;

    public MessageBubble(String text, boolean isUser) {
        this.text = text;
        this.isUser = isUser;
        this.timestamp = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("hh:mm a"));
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        FontMetrics fm = g2.getFontMetrics(new Font("SansSerif", Font.PLAIN, 14));
        int padding = 10;
        int arc = 20;
        int maxWidth = 250;

        // Wrap text logic
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        int y = padding + fm.getAscent();
        int lineHeight = fm.getHeight();
        
        // Simple bounding box for bubble
        int bubbleWidth = Math.min(maxWidth, fm.stringWidth(text) + padding * 2);
        int x = isUser ? getWidth() - bubbleWidth - padding : padding;

        g2.setColor(isUser ? new Color(173, 216, 230) : new Color(225, 225, 225));
        g2.fillRoundRect(x, padding/2, bubbleWidth, getHeight() - padding - 10, arc, arc);

        g2.setColor(Color.BLACK);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        
        // Draw the text (simplified wrapping for this example)
        g2.drawString(text.length() > 35 ? text.substring(0, 32) + "..." : text, x + padding, y);

        // Timestamp
        g2.setFont(new Font("SansSerif", Font.PLAIN, 9));
        g2.setColor(Color.DARK_GRAY);
        g2.drawString(timestamp, x + (bubbleWidth - 50), getHeight() - 5);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(450, 60); // Standard height for bubble
    }
}