import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {
    static List<PrintWriter> writers = new ArrayList<>();
    
    public static void main(String[] args) throws Exception {
        ServerSocket server = new ServerSocket(5000);
        System.out.println("Server running on port 5000");
        
        while (true) {
            Socket client = server.accept();
            System.out.println("Client connected");
            
            new Thread(() -> {
                try {
                    BufferedReader in = new BufferedReader(
                        new InputStreamReader(client.getInputStream()));
                    PrintWriter out = new PrintWriter(client.getOutputStream(), true);
                    
                    // Add client
                    synchronized (writers) {
                        writers.add(out);
                    }
                    
                    // Read name
                    String name = in.readLine();
                    System.out.println(name + " joined");
                    
                    // Send to all
                    for (PrintWriter w : writers) {
                        w.println(name + " joined the chat");
                    }
                    
                    // Handle messages
                    String message;
                    while ((message = in.readLine()) != null) {
                        System.out.println(name + ": " + message);
                        for (PrintWriter w : writers) {
                            w.println(name + ": " + message);
                        }
                    }
                    
                } catch (IOException e) {
                	
					System.out.println("Client disconnected");
                }
            }).start();
        }
    }
}